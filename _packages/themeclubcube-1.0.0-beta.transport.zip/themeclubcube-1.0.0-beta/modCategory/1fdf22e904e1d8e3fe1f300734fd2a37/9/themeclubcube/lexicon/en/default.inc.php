<?php

// setting
$_lang['setting_themeclubcube_resources.themeclubcube_partners_resource'] = 'Partners resource ID';
$_lang['setting_themeclubcube_resources.themeclubcube_partners_resource_desc'] = 'Resource ID for a list of partners';
