<?php
class TicketView extends xPDOObject {}