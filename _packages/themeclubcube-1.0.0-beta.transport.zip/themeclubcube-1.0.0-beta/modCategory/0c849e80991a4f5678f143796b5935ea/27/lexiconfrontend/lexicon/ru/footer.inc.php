<?php

$_lang['lf_footer_welcome_line'] = 'Нам нравится создавать классные вечеринки и мы любим общаться с единомышленниками';
$_lang['lf_footer_welcome_head'] = 'Не стесняйтесь поздороваться!';

$_lang['lf_footer_address_email'] = 'hello@themecubeclub.sample';
$_lang['lf_footer_address_phone1'] = '+38 (000) 000-00-00';
$_lang['lf_footer_address_phone2'] = '+38 (000) 000-00-00';
$_lang['lf_footer_address'] = '87500 Украина, Мариуполь, ул. Казанцева 7б, 2й этаж, оф. 29';

$_lang['lf_footer_subscribe_head'] = 'Список рассылки';
$_lang['lf_footer_subscribe_line'] = 'Введите адрес вашей электронной почты ниже, чтобы подписаться на наши рассылки вечеринок. Мы обещаем делать вас счастливыми очень-очень часто!';
$_lang['lf_footer_subscribe_email_placeholder'] = 'Ваш E-mail';
$_lang['lf_footer_subscribe_send'] = 'Подписаться';
$_lang['lf_footer_subscribe_success'] = 'Спасибо!';

$_lang['lf_footer_follow_head'] = 'Следуй за нами';
$_lang['lf_footer_follow_line'] = 'Чтобы получать самую актуальную информацию';
$_lang['lf_footer_follow_facebook'] = '#';
$_lang['lf_footer_follow_gplus'] = '#';
$_lang['lf_footer_follow_linkedin'] = '#';
$_lang['lf_footer_follow_twitter'] = '#';
$_lang['lf_footer_follow_skype'] = '#';
$_lang['lf_footer_follow_pinterest'] = '#';
$_lang['lf_footer_follow_youtube'] = '#';
$_lang['lf_footer_follow_flickr'] = '#';

$_lang['lf_footer_copyright'] = 'Сopyright';
$_lang['lf_footer_copyright_text'] = '- Theme Cube Club. Все права защищены.';