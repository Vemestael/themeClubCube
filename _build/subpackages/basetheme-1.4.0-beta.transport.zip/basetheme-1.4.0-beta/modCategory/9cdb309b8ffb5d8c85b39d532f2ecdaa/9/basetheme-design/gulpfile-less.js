'use strict';

var gulp = require('gulp');
var less = require('gulp-less');
var debug = require('gulp-debug');
var sourcemaps = require('gulp-sourcemaps');
var autoprefixer = require('gulp-autoprefixer');
var jade = require('gulp-jade');
var plumber = require('gulp-plumber');
var path = require('path');
var bs = require('browser-sync').create();

gulp.task('serve', function () {

  bs.init({
    server: {
      baseDir: "./"
    }
  });

  gulp.watch("css/*.css").on('change', bs.reload);
  gulp.watch("*.html").on('change', bs.reload);
});

gulp.task('less', function () {
  return gulp.src(['css/less/*.less'])
    .pipe(sourcemaps.init())
    .pipe(less({
      paths: [ path.join(__dirname, 'less', 'includes') ]
    }))
    .pipe(debug({title: 'less:'}))
    .pipe(autoprefixer({
      browsers: [
        'Chrome >= 35',
        'Firefox >= 31',
        'Edge >= 12',
        'Explorer >= 9',
        'iOS >= 8',
        'Safari >= 8',
        'Android 2.3',
        'Android >= 4',
        'Opera >= 12'
      ],
      cascade: true
    }))
    .pipe(debug({title: 'prefx:'}))
    .pipe(sourcemaps.write())
    .pipe(debug({title: 'maps:'}))
    .pipe(gulp.dest('css'));
  callback();
});

gulp.task('templates', function (callback) {
  gulp.src('jade/*.jade')
    .pipe(plumber())
    .pipe(jade({
      pretty: true,
    }))
    .pipe(gulp.dest('.'))
    .pipe(debug({title: 'jade:'}));
  callback();
});

gulp.task('watch', function () {
  gulp.watch( ['css/less/**/**/*.less'], ['less']);
  gulp.watch('jade/**/*.*', ['templates']);
});

gulp.task('default', ['serve', 'templates', 'less', 'watch']);