<?php

$_lang['lf_footer_welcome_line'] = 'Нам подобається створювати класні вечірки та ми любимо спілкуватися з однодумцями';
$_lang['lf_footer_welcome_head'] = 'Не соромтесь привітатися!';

$_lang['lf_footer_address_email'] = 'hello@themecubeclub.sample';
$_lang['lf_footer_address_phone1'] = '+38 (000) 000-00-00';
$_lang['lf_footer_address_phone2'] = '+38 (000) 000-00-00';
$_lang['lf_footer_address'] = '87500 Україна, Маріуполь, вул. Казанцева 7б, 2й поверх, оф. 29';

$_lang['lf_footer_subscribe_head'] = 'Список розсилки';
$_lang['lf_footer_subscribe_line'] = 'Введіть адресу вашої електронної пошти нижче, щоб оформити підписку на наші розсилки вечірок. Ми обіцяємо робити вас щасливими дуже-дуже часто!';
$_lang['lf_footer_subscribe_email_placeholder'] = 'Ваш E-mail';
$_lang['lf_footer_subscribe_send'] = 'Підписатися';
$_lang['lf_footer_subscribe_success'] = 'Дякуємо!';

$_lang['lf_footer_follow_head'] = 'Слідуй за нами';
$_lang['lf_footer_follow_line'] = 'Щоб отримувати найактуальнішу інформацію';
$_lang['lf_footer_follow_facebook'] = '#';
$_lang['lf_footer_follow_gplus'] = '#';
$_lang['lf_footer_follow_linkedin'] = '#';
$_lang['lf_footer_follow_twitter'] = '#';
$_lang['lf_footer_follow_skype'] = '#';
$_lang['lf_footer_follow_pinterest'] = '#';
$_lang['lf_footer_follow_youtube'] = '#';
$_lang['lf_footer_follow_flickr'] = '#';

$_lang['lf_footer_copyrigt'] = '- Theme Cube Club. Всі права захищені.';