$(function(){
    appMakeBeCool.gateway.init();
});