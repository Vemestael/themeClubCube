"use strict";
appMakeBeCool.gateway.addClass('FormValidate', function (properties, $, $window, $document) {
  //PRIVATE VARIABLES
  var _formValidate = this,
      _d = {
        // elements
        forms: []

        // prop
        // data
        // classes ans styles
      },
      _p = $.extend(_d, properties),
      _g = {
        // elements
        forms: [],

        // prop
        preloaded: false
      },

  //PRIVATE METHODS
      _init = function () {
        appMakeBeCool.gateway.base.Class.apply(_formValidate, [_p]);
        if (!_g.preloaded) {
          return _formValidate.init();
        }
        _formValidate.globals.customCreate = function () {
          _config();
          _setup();
          _setBinds();
          _setCustomMethods();
        };
        _formValidate.create();
      },

      _config = function () {
        if (_p.forms.length) {
          for (var i in _p.forms) {
            _g.forms.push($(_p.forms[i]));
          }
        }
      },

      _setup = function () {
        if (_g.forms.length) {
          for (var i in _g.forms) {
            _g.forms[i].validate({
              rules: {
                name: {
                  required: true,
                  minlength: 2
                },
                username: {
                  required: true,
                },
                password: {
                  required: true,
                },
                age: {
                  required: true,
                  min: 1,
                },
                review: {
                  required: true,
                },
                fullname: {
                  required: true,
                  minlength: 2
                },
                email: {
                  required: true,
                  email: true
                },
                skype: {
                  required: true
                },
                phone: {
                  required: true,
                  regx: /[0-9\-\+\(\)]{9}/
                }
              },
              messages: {
                username: {
                  required: typeof global.validationMessages.username === 'undefined' ? '' : global.validationMessages.username
                },
                password: {
                  required: typeof global.validationMessages.password === 'undefined' ? '' : global.validationMessages.password
                },
                name: {
                  required: typeof global.validationMessages.name === 'undefined' ? '' : global.validationMessages.name,
                  minlength: typeof global.validationMessages.nameMinLength === 'undefined' ? '' : global.validationMessages.nameMinLength
                },
                age: {
                  required: typeof global.validationMessages.age === 'undefined' ? '' : global.validationMessages.age,
                  min: typeof global.validationMessages.age === 'undefined' ? '' : global.validationMessages.age,
                },
                course: {
                  required: typeof global.validationMessages.course === 'undefined' ? '' : global.validationMessages.course,
                },
                review: {
                  required: typeof global.validationMessages.review === 'undefined' ? '' : global.validationMessages.review,
                },
                img: {
                  required: typeof global.validationMessages.img === 'undefined' ? '' : global.validationMessages.img,
                },
                surname: typeof global.validationMessages.surname === 'undefined' ? '' : global.validationMessages.surname,
                fullname: {
                  required: typeof global.validationMessages.name === 'undefined' ? '' : global.validationMessages.name,
                  minlength: typeof global.validationMessages.nameMinLength === 'undefined' ? '' : global.validationMessages.nameMinLength
                },
                brand: typeof global.validationMessages.brand === 'undefined' ? '' : global.validationMessages.brand,
                date: typeof global.validationMessages.date === 'undefined' ? '' : global.validationMessages.date,
                country: typeof global.validationMessages.country === 'undefined' ? '' : global.validationMessages.country,
                phone: {
                  required: typeof global.validationMessages.phoneRequired === 'undefined' ? '' : global.validationMessages.phoneRequired,
                  regx: typeof global.validationMessages.phone === 'undefined' ? '' : global.validationMessages.phone,
                },
                address: typeof global.validationMessages.address === 'undefined' ? '' : global.validationMessages.address,
                addresses: typeof global.validationMessages.addresses === 'undefined' ? '' : global.validationMessages.addresses,
                url: typeof global.validationMessages.url === 'undefined' ? '' : global.validationMessages.url,
                email: {
                  required: typeof global.validationMessages.emailRequired === 'undefined' ? '' : global.validationMessages.emailRequired,
                  email: typeof global.validationMessages.email === 'undefined' ? '' : global.validationMessages.email,
                },
                text: typeof global.validationMessages.text === 'undefined' ? '' : global.validationMessages.text,
                skype: {
                  required: typeof global.validationMessages.skypeRequired === 'undefined' ? '' : global.validationMessages.skypeRequired,
                },
                message: typeof global.validationMessages.message === 'undefined' ? '' : global.validationMessages.message,
              },
              highlight: function (element) {

              },
              unhighlight: function (element) {

              }
            });
          }
        }

        _phoneInputMask();
      },

      _setBinds = function () {
      },

      _binds = function () {
        return {}
      },

      _triggers = function () {
        return {}
      },

      _phoneInputMask = function () {
        if ($('input[type="tel"]').length) {
          $('input[type="tel"]').inputmask({
            mask: '+99 (999) 99-99-999',
            placeholder: ' ',
            showMaskOnHover: false,
            showMaskOnFocus: true,
            onBeforePaste: function (pastedValue, opts) {
              var processedValue = pastedValue;
              return processedValue;
            }
          });
        }
      },

      _setCustomMethods = function () {
        _formValidate.globals.customResurrect = function () {
        };
        _formValidate.globals.customDestroy = function () {
        };
      };

  //PUBLIC METHODS
  _formValidate.addMethod('init', function () {
    _formValidate.bind($window, _formValidate.globals.classType + '_Init', function (e, data, el) {
      _g.preloaded = true;
      _init();
    });
  });

  //GO!
  _init();
});