<?php

$_lang['lf_page_prev'] = 'Пред.';
$_lang['lf_page_next'] = 'След.';

$_lang['lf_month.01'] = 'Январь';
$_lang['lf_month.02'] = 'Февраль';
$_lang['lf_month.03'] = 'Март';
$_lang['lf_month.04'] = 'Апрель';
$_lang['lf_month.05'] = 'Май';
$_lang['lf_month.06'] = 'Июнь';
$_lang['lf_month.07'] = 'Июль';
$_lang['lf_month.08'] = 'Август';
$_lang['lf_month.09'] = 'Сентябрь';
$_lang['lf_month.10'] = 'Октябрь';
$_lang['lf_month.11'] = 'Ноябрь';
$_lang['lf_month.12'] = 'Декабрь';

$_lang['lf_month_short.01'] = 'Янв';
$_lang['lf_month_short.02'] = 'Фев';
$_lang['lf_month_short.03'] = 'Мар';
$_lang['lf_month_short.04'] = 'Апр';
$_lang['lf_month_short.05'] = 'Май';
$_lang['lf_month_short.06'] = 'Июн';
$_lang['lf_month_short.07'] = 'Июл';
$_lang['lf_month_short.08'] = 'Авг';
$_lang['lf_month_short.09'] = 'Сен';
$_lang['lf_month_short.10'] = 'Окт';
$_lang['lf_month_short.11'] = 'Ноя';
$_lang['lf_month_short.12'] = 'Дек';

$_lang['lf_week.0']='Пн';
$_lang['lf_week.1']='Вт';
$_lang['lf_week.2']='Ср';
$_lang['lf_week.3']='Чт';
$_lang['lf_week.4']='Пт';
$_lang['lf_week.5']='Сб';
$_lang['lf_week.6']='Вс';