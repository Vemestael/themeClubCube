<?php

$_lang['lf_footer_welcome_line'] = 'We like to create cool parties and we love to chat with like-minded';
$_lang['lf_footer_welcome_head'] = 'Do not hesitate to say hello!';

$_lang['lf_footer_address_email'] = 'hello@cubeclub.com';
$_lang['lf_footer_address_phone1'] = '+38 (000) 000-00-00';
$_lang['lf_footer_address_phone2'] = '+38 (000) 000-00-00';
$_lang['lf_footer_address'] = '87500 Mariupol, Ukraine, ul. Kazantsev 7b, 2nd floor, office. 29';

$_lang['lf_footer_subscribe_head'] = 'Mailing list';
$_lang['lf_footer_subscribe_line'] = 'Enter your E-mail below to subscribe to our partiesletter. We promise to make you happy very very often!';
$_lang['lf_footer_subscribe_email_placeholder'] = 'Your E-mail';
$_lang['lf_footer_subscribe_send'] = 'Subscribe';

$_lang['lf_footer_follow_head'] = 'Follow us';
$_lang['lf_footer_follow_line'] = 'To be up-to-date with us';
$_lang['lf_footer_follow_facebook'] = '#';
$_lang['lf_footer_follow_gplus'] = '#';
$_lang['lf_footer_follow_linkedin'] = '#';
$_lang['lf_footer_follow_twitter'] = '#';
$_lang['lf_footer_follow_skype'] = '#';
$_lang['lf_footer_follow_pinterest'] = '#';
$_lang['lf_footer_follow_youtube'] = '#';
$_lang['lf_footer_follow_flickr'] = '#';

$_lang['lf_footer_copyright'] = 'Copyright';
$_lang['lf_footer_copyright_text'] = '- Cube Club. All Rights Reserved.';