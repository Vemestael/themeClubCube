--------------------
baseTheme
--------------------
Author: Andrei Gadashevich <gav.andrei@makebecool.com>
--------------------

This basic template for designing websites, including best practices in the design studio MakeBeCool.

Feel free to suggest ideas/improvements/bugs on Email:
support@makebecool.com