<?php

$_lang['lf_site_name'] = ' / Theme Club Cube';

$_lang['lf_description'] = 'Розробка шаблонів для MODX від дизайн студії MakeBeCool.com';