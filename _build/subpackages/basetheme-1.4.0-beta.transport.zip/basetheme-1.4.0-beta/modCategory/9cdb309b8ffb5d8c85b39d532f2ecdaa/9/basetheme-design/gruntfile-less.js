module.exports = function (grunt) {
  grunt.initConfig({
    less: {
      dev: {
        options: {
          sourceMap: true,
          dumpLineNumbers: 'comments',
          relativeUrls: true,
          plugins: [
            new (require('less-plugin-autoprefix'))({browsers: ["last 2 versions"]})
          ]
        },
        files: {
          '../style.css': '../style.less',
          //'../base64-fonts.css': '../base64-fonts.less',
        }
      },
      //production: {
      //  options: {
      //    compress: true,
      //    relativeUrls: true,
      //    plugins: [
      //      new (require('less-plugin-autoprefix'))({browsers: ["last 2 versions"]})
      //    ]
      //  },
      //  files: {
      //    'Content/Site.css': 'Content/Site.less',
      //  }
      //}
    },
    watch: {
      files: ['*.less', '../style.less'],
      tasks: ['less'],
    }


  });

  grunt.loadNpmTasks('grunt-contrib-less');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.registerTask('default', ['less', 'watch']);
  //grunt.registerTask('production', ['less:production']);

  grunt.registerTask('dev', ['less:dev']);
}