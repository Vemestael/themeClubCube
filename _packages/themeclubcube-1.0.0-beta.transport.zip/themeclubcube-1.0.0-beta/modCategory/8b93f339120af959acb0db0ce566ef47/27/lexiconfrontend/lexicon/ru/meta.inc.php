<?php

$_lang['lf_site_name'] = ' / Theme Club Cube';

$_lang['lf_description'] = 'Разработка шаблонов для MODX от дизайн-студии MakeBeCool.com';