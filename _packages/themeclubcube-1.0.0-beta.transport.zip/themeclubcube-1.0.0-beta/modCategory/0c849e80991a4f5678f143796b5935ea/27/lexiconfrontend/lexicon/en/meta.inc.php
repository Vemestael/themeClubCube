<?php

$_lang['lf_site_name'] = ' / Theme Club Cube';

$_lang['lf_description'] = 'Development templates for MODX form MakeBeCool.com design studio';