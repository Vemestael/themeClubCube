<?php
require_once (dirname(dirname(__FILE__)) . '/ticket.class.php');
class Ticket_mysql extends Ticket {}