<?php
class TicketVote extends xPDOObject {}