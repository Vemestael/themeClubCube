<?php

$_lang['lf_site_name'] = ' / Example.com';

$_lang['lf_description'] = '';
$_lang['lf_description_content'] = '';
$_lang['lf_description_blog'] = '';

$_lang['lf_title_content'] = '';
$_lang['lf_title_blog'] = '';