<?php
class TicketStar extends xPDOObject {}